## Vim
- Markdown support
- Snippets
- Eslint/Hint

## Tmux
- Windows listed @ bottom like in Tmux talk
- Pop-up for Git commands

## i3
- Vpn status
- Better notifications
- Screenshot tool
- Nicer i3lock

## Linux
- Disable all audio except Yeti

